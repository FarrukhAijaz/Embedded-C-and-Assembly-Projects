#include "TM4C123GH6PM.h"
#include "Pulse_init_q1.h"

int main(){
pulse_init();
while(1){
}


}